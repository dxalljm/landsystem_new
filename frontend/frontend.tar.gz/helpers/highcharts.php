<?php
namespace frontend\controllers;
use yii;
class highcharts
{
	public function runJs()
	{
		echo '<script>';
		echo 'alert("ffffffff");';
		echo '</script>';
	}
}